<div class="container-fluid" style="background-color: #703684; color: white">
    <?php echo form_open("auth/login"); ?>
    <div class="row">
        <div class="col-md-4">
            <a href="<?php echo base_url(); ?>">
                <div style="text-align: center; padding-top: 14px; padding-left: 90px;">
                    <img class="img-circle" src="<?php echo base_url(); ?>resources/images/logo.png" style="margin: 0px 3px 20px 0px;">
                    <img src="<?php echo base_url(); ?>resources/images/shadhiin.com.png" style="margin: 0px 10px 22px 0px; border-radius: 3px;">
                </div>
            </a>
        </div>
        <div class="col-md-8"></div>
    </div>
    <?php echo form_close(); ?>
</div>

