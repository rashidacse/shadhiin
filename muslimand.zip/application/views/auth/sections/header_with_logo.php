<div class="container-fluid" style="padding-top: 10px; margin-bottom: -6px; background-color: #703684; color: white">
    <div class="row">
        <?php echo form_open("auth/login"); ?>
        <div class="col-md-4" style="padding-bottom: 10px;">            
            <div align="center" style="text-align: center; padding-top: 10px; padding-left: 10px;">
                <a href="<?php echo base_url(); ?>">
                    <img src="<?php echo base_url(); ?>resources/images/logo.png" style="margin: 0px 10px 22px 0px; border-radius: 3px;">
                    <img src="<?php echo base_url(); ?>resources/images/sadiik.com.png" style="margin: 0px 10px 22px 0px; border-radius: 3px;">
                </a>
            </div>			
        </div>
        <div class="col-md-offset-8"></div>
        <?php echo form_close(); ?>
    </div>
</div>

