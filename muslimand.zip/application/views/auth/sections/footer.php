<div class="container">
    <div class="padding_top_20px">
        <div style="color: #703684; margin-left: -15px;">
            <a href="<?php echo base_url(); ?>footer/about">About</a> | <a href="<?php echo base_url(); ?>footer/contact">Contact</a> | <a href="<?php echo base_url(); ?>member/invite">Invite</a> | <a href="<?php echo base_url(); ?>footer/privacy">Privacy</a> | <a href="<?php echo base_url(); ?>footer/terms">Terms</a>
        </div>
    </div>
</div>