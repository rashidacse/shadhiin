<div class="row form-group">
    <div class="col-md-12">
        <span style="font-size: 16px; font-weight: bold;">Friend's Pages</span>
    </div>
</div>
<div class="pagelet_divider"></div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_friend/50_50/01.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Barak Obama</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Public</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>956 members</li>
                </ul>
                <div class="extra_info">
                    <ul class="extra_info_middot">
                        <a href="#">Like .</a>
                        <a href="#"> Share</a>
                    </ul>
                </div>
                <div class="borber_style">
                    <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                    <a href="#">259 people</a>
                    like this.
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_friend/50_50/02.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Mountain</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Place</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>697 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">321 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_friend/50_50/03.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Fear Allah</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Public</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>3,987 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">553 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_friend/50_50/04.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Zina in Islam</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Community</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>698 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">156 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_friend/50_50/05.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Sakib Al Hasan</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Public</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>20,654 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">1,023 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_friend/50_50/06.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Bilal Philips</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Public</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>2,698 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">789 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_friend/50_50/07.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Bill Gates</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Public</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>5,493 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">769 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_friend/50_50/08.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">MAC Desktop</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Business</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>859 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">412 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_friend/50_50/09.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Tsunami</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>public</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>6,987 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">992 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_friend/50_50/10.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Child Labour</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>community</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>2,283 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">525 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row">
    <div class="col-md-4">
        <span>1-10 of 150 Results</span>
    </div>
    <div class="col-md-8">
        <nav style="float: right;">
            <ul class="pagination pagination_margin">
                <li>
                    <a href="<?php echo base_url(); ?>videos/videos_iframe" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <li><a href="">1</a></li>
                <li><a href="">2</a></li>
                <li><a href="">3</a></li>
                <li><a href="">4</a></li>
                <li><a href="">5</a></li>
                <li>
                    <a href="" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group"></div>
