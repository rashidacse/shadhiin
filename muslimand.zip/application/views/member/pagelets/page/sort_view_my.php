<div class="row form-group">
    <div class="col-md-12">
        <span style="font-size: 16px; font-weight: bold;">My Pages</span>
    </div>
</div>
<div class="pagelet_divider"></div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_my/50_50/01.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Tawheedullaah</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Website</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>4,313 members</li>
                </ul>
                <div class="extra_info">
                    <ul class="extra_info_middot">
                        <a href="#">Like .</a>
                        <a href="#"> Share</a>
                    </ul>
                </div>
                <div class="borber_style">
                    <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                    <a href="#">279 people</a>
                    like this.
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_my/50_50/02.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Quraner Alo</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Website</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>5,547 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">983 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_my/50_50/03.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">BRACU Chondroboat</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Institute</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>787 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">253 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_my/50_50/04.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Bangladesh Cricket News</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Public</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>5,555 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">1,395 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_my/50_50/05.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Cricinfo</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Sports</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>3,589 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">987 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_my/50_50/06.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Lectures of Zakir Naik</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>PublicS</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>3,423 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">679 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_my/50_50/07.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Flower</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Beauty</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>658 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">64 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_my/50_50/08.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Dress Corner</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>group</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>689 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">256 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_my/50_50/09.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Arabic Learning</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Common Interest</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>645 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">223 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row img_padding_top">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>pages/pages_newsfeed" >
            <img class="img-circle" src="<?php echo base_url(); ?>resources/images/pages/view_my/50_50/10.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="title_info">
            <a class="link" href="<?php echo base_url(); ?>pages/pages_newsfeed">Quotes</a>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <li>Community</li>
                    <li>
                        <span>·</span>
                    </li>
                    <li>694 members</li>
                </ul>
            </div>
            <div class="extra_info">
                <ul class="extra_info_middot">
                    <a href="#">Like .</a>
                    <a href="#"> Share</a>
                </ul>
            </div>
            <div class="borber_style">
                <img width="35" height="35" src="<?php echo base_url(); ?>resources/images/like_icon.png">
                <a href="#">259 people</a>
                like this.
            </div>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row">
    <div class="col-md-4">
        <span>1-10 of 85 Results</span>
    </div>
    <div class="col-md-8">
        <nav style="float: right;">
            <ul class="pagination pagination_margin">
                <li>
                    <a href="<?php echo base_url(); ?>videos/videos_iframe" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <li><a href="">1</a></li>
                <li><a href="">2</a></li>
                <li><a href="">3</a></li>
                <li><a href="">4</a></li>
                <li><a href="">5</a></li>
                <li>
                    <a href="" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group"></div>
