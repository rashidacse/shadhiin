<div class="row form-group">
    <div class="col-md-12">
        <span style="font-size: 16px; font-weight: bold;">All Albums</span>
    </div>
</div>
<div class="pagelet_divider"></div>
<div class="row form-group"></div>
<div class="row form-group font_11px">
    <div class="col-md-3">
        <a href="" >
            <img style="border: 1px solid #703684;" src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_2.jpg" width="120" height="100">
        </a>
        <div>
            <a href="" > Profile Pictures</a><br>
            72 photos
        </div>
    </div>
    <div class="col-md-3">
        <a href="" >
            <img style="border: 1px solid #703684;" src="<?php echo base_url(); ?>resources/images/photos/view_my_albums/cover_photos/03.jpg" width="120" height="100">
        </a>
        <div>
            <a href="" >Cover</a><br>
            102 photos
        </div>
        
    </div>
    <div class="col-md-3">
        <a href="" >
            <img style="border: 1px solid #703684;" src="<?php echo base_url(); ?>resources/images/photos/albums/English_Cotton/04.jpg" width="120" height="100">
        </a>
        <div>
            <a href="" > English Cotton</a><br>
            35 photos
        </div>
    </div>
    <div class="col-md-3">
        <a href="" >
            <img style="border: 1px solid #703684;" src="<?php echo base_url(); ?>resources/images/photos/albums/Perfumes/04.jpg" width="120" height="100">
        </a>
        <div>
            <a href="" >Perfumes</a><br>
            78 photos
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group font_11px">
    <div class="col-md-3">
        <a href="" >
            <img style="border: 1px solid #703684;" src="<?php echo base_url(); ?>resources/images/photos/albums/Islamic_life/07.jpg" width="120" height="100">
        </a>
        <div>
            <a href="" >Islamic life</a><br>
            93 photos
        </div>
    </div>
    <div class="col-md-3">
        
    </div>
    <div class="col-md-3">
        
    </div>
    <div class="col-md-3">
        
    </div>
</div>
<div class="row form-group"></div>
<div class="row">
    <div class="col-md-4">
        <span>1-5 of 666 Results</span>
    </div>
    <div class="col-md-8">
        <nav style="float: right;">
            <ul class="pagination pagination_margin">
                <li>
                    <a href="<?php echo base_url(); ?>videos/videos_iframe" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <li><a href="">1</a></li>
                <li><a href="">2</a></li>
                <li><a href="">3</a></li>
                <li><a href="">4</a></li>
                <li><a href="">5</a></li>
                <li>
                    <a href="" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>
