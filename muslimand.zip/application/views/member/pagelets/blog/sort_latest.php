<div class="row form-group form-group">
    <div class="col-md-12">
        <span style="font-size: 16px; font-weight: bold;">All Blogs</span>
    </div>
</div>
<div class="pagelet_divider"></div>
<div class="row form-group padding_top_over_row form-group">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>member/profile" >
            <img height="50" width="50" class="img-circle" src="<?php echo base_url(); ?>resources/images/blogs/50_50/01.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="row">
            <div class="col-md-12">
                <a style="text-decoration: none; color: black; cursor: pointer;" href="<?php echo base_url(); ?>blogs/blogs_newsfeed"><h4>Wealth</h4></a>
                by
                <a href="<?php echo base_url(); ?>member/profile">Mohammad Azhar Uddin</a><br><br>
                <p style="text-align: justify;">Using Wealth Rasulullah Sallallahu Alayhi wa Sallam said: "Verily, those who have the most [wealth] 
                    will be the ones with least on the Day of Resurrection except for the one who says, 'This is for that, 
                    this for that and this is for that [in other words, he gives the wealth away for good causes].'" 
                    [Bukhari, Muslim] In general, gathering a lot of wealth in this world takes up a lot of time and ef... </p>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <a href="#" >Like .</a>
                <a href="#" > Share</a>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <img src="<?php echo base_url(); ?>resources/images/like_icon.png" >
                <a href="#">37 people </a> like this.
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <img src="<?php echo base_url(); ?>resources/images/comment_icon.png">
                <a href="<?php echo base_url(); ?>blogs/blogs_newsfeed">view 19 more comments</a>
            </div>
        </div>
    </div>
</div>
<div class="row form-group padding_top_over_row form-group">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>member/profile" >
            <img height="50" width="50" class="img-circle" src="<?php echo base_url(); ?>resources/images/blogs/50_50/02.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="row">
            <div class="col-md-12">
                <a style="text-decoration: none; color: black; cursor: pointer;" href="<?php echo base_url(); ?>blogs/blogs_newsfeed"><h4>Do you Believe in God?</h4></a>
                by
                <a href="<?php echo base_url(); ?>member/profile">Jannatul Ferdaus</a><br><br>
                <p style="text-align: justify;"> “How can you believe in God when you can’t see Him?” I was presented with this argument shortly 
                    after embracing Islam. My response was “Do you believe in love, even though you can’t see it?” Of course, we know that love 
                    is a feeling but how is it possible to feel? Only Allah (swt) can show us love, cause us to feel love, help us to see love 
                    in even the most hateful of situations. Allah (swt) h... </p>   
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <a href="#" >Like .</a>
                <a href="#" > Share</a>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <img src="<?php echo base_url(); ?>resources/images/like_icon.png" >
                <a href="#">317 people </a> like this.
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <img src="<?php echo base_url(); ?>resources/images/comment_icon.png">
                <a href="<?php echo base_url(); ?>blogs/blogs_newsfeed">view 27 more comments</a>
            </div>
        </div>
    </div>
</div>
<div class="row form-group padding_top_over_row form-group">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>member/profile" >
            <img height="50" width="50" class="img-circle" src="<?php echo base_url(); ?>resources/images/blogs/50_50/03.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="row">
            <div class="col-md-12">
                <a style="text-decoration: none; color: black; cursor: pointer;" href="<?php echo base_url(); ?>blogs/blogs_newsfeed"><h4>You won't have second chance to come back !</h4></a>
                by
                <a href="<?php echo base_url(); ?>member/profile">Sharmin Akter</a><br><br>
                <p style="text-align: justify;">In the Name of God, Most Gracious, Most Merciful PREFACE How would you react if you were to see 
                    a child coming barefoot and about to step onto a tiny, burning ember shouldering on the ground? Obviously, you would, at once, 
                    rush to the child and sweep him off into your arms. And, what a huge sense of relief and satisfaction would you experience by 
                    thus drawing him away from the flames! In much ... </p>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <a href="#" >Like .</a>
                <a href="#" > Share</a>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <img src="<?php echo base_url(); ?>resources/images/like_icon.png" >
                <a href="#">337 people </a> like this.
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <img src="<?php echo base_url(); ?>resources/images/comment_icon.png">
                <a href="<?php echo base_url(); ?>blogs/blogs_newsfeed">view 58 more comments</a>
            </div>
        </div>
    </div>
</div>
<div class="row form-group padding_top_over_row form-group">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>member/profile" >
            <img height="50" width="50" class="img-circle" src="<?php echo base_url(); ?>resources/images/blogs/50_50/04.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="row">
            <div class="col-md-12">
                <a style="text-decoration: none; color: black; cursor: pointer;" href="<?php echo base_url(); ?>blogs/blogs_newsfeed"><h4>10 Best Qualities in Quran to be followed by a Teenager</h4></a>
                by
                <a href="<?php echo base_url(); ?>member/profile">Maria Islam</a><br><br>
                <p style="text-align: justify;">1. Be Truthful: Being truthful is the most difficult thing for a teenager in this competitive society.
                    Somehow in someways, they tend to compose lies, fearing their parents or teachers. If missed to do a school work or something like 
                    a project, you intend to tell a lie for it, in order to get rid from the punishment. If you do a mistake, you try to conceal the 
                    truth from your parents, but keep ... </p>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <a href="#" >Like .</a>
                <a href="#" > Share</a>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <img src="<?php echo base_url(); ?>resources/images/like_icon.png" >
                <a href="#">587 people </a> like this.
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <img src="<?php echo base_url(); ?>resources/images/comment_icon.png">
                <a href="<?php echo base_url(); ?>blogs/blogs_newsfeed">view 97 more comments</a>
            </div>
        </div>
    </div>
</div>
<div class="row form-group padding_top_over_row form-group">
    <div class="col-md-2">
        <a href="<?php echo base_url(); ?>member/profile" >
            <img height="50" width="50" class="img-circle" src="<?php echo base_url(); ?>resources/images/blogs/50_50/05.jpg">
        </a>
    </div>
    <div class="col-md-10">
        <div class="row">
            <div class="col-md-12">
                <a style="text-decoration: none; color: black; cursor: pointer;" href="<?php echo base_url(); ?>blogs/blogs_newsfeed"><h4>Why Read the Quran?</h4></a>
                by
                <a href="<?php echo base_url(); ?>member/profile">Dr. Belal</a><br><br>
                <p style="text-align: justify;">Who, What, When and How with Quran We live life each day caught up in the spur of every moment, stressed 
                    with our occupations, with school, with the responsibilities of maintaining a family. It can be overwhelming to think of all of the 
                    things on our to do list, who has to go where and what needs to be done, and let’s not forget our deadlines. Meanwhile, we wonder how 
                    in the world we are ever goi... </p>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <a href="#" >Like .</a>
                <a href="#" > Share</a>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <img src="<?php echo base_url(); ?>resources/images/like_icon.png" >
                <a href="#">55 people </a> like this.
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-12">
                <img src="<?php echo base_url(); ?>resources/images/comment_icon.png">
                <a href="<?php echo base_url(); ?>blogs/blogs_newsfeed">view 13 more comments</a>
            </div>
        </div>
    </div>
</div>


<div class="row form-group form-group"></div>
<div class="row form-group">
    <div class="col-md-4">
        <span>1-5 of 500 Results</span>
    </div>
    <div class="col-md-8">
        <nav style="float: right;">
            <ul class="pagination pagination_margin">
                <li>
                    <a href="<?php echo base_url(); ?>videos/videos_iframe" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <li><a href="">1</a></li>
                <li><a href="">2</a></li>
                <li><a href="">3</a></li>
                <li><a href="">4</a></li>
                <li><a href="">5</a></li>
                <li>
                    <a href="" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>
<div class="row form-group form-group"></div>
<div class="row form-group form-group"></div>
