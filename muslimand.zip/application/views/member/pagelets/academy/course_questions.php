<div class="row padding_top_over_row">
    <div class="col-md-12">
        <a style="text-decoration: none; color: black; cursor: pointer;" href="<?php echo base_url(); ?>academy/academy_course_home"><span style="font-size: 22px; font-weight: bold;">Quran Reading</span></a>
    </div>
</div>
<div class="row padding_top_over_row">
    <div class="col-md-6">
        <a  href=""><button class="btn btn-xs" style="float: left; background-color: #703684; color: white; font-weight: bold; padding: 3px 28px;">Lectures</button></a>
    </div>
    <div class="col-md-6">
        <a  href=""><button class="btn btn-xs" style="float: right; background-color: #703684; color: white; font-weight: bold; padding: 3px 28px;">Cancel Membership</button></a>
    </div>
</div>
<div class="pagelet_divider"></div>
<div class="row padding_top_over_row">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-12">
                <a href="#" ><img style="padding: 2px; border-radius: 5px;"src="<?php echo base_url(); ?>resources/images/logins/facebook.png" ></a>
                <a href="#" ><img style="padding: 2px; border-radius: 5px;"src="<?php echo base_url(); ?>resources/images/logins/google.png" ></a>
                <a href="#" ><img style="padding: 2px; border-radius: 5px;"src="<?php echo base_url(); ?>resources/images/logins/twitter.png" ></a>
                <a href="#" ><img style="padding: 2px; border-radius: 5px;"src="<?php echo base_url(); ?>resources/images/logins/linkedin.png" ></a>
                <a href="#" ><img style="padding: 2px; border-radius: 5px;"src="<?php echo base_url(); ?>resources/images/logins/yahoo.png" ></a>
                <a href="#" ><img style="padding: 2px; border-radius: 5px;"src="<?php echo base_url(); ?>resources/images/logins/live.png" ></a>
            </div>
        </div>
        <div class="row padding_top_over_row">
            <div class="col-md-12">
                <a href="#" >Like .</a>
                <a href="#" > Share</a>
            </div>
        </div>
        <div class="row padding_top_over_row">
            <div class="col-md-12">
                <img src="<?php echo base_url(); ?>resources/images/like_icon.png" >
                <a href="#">37 people </a> like this.
            </div>
        </div>
        <div class="pagelet_divider"></div>
        <div class="row">
            <div class="col-md-12">
                <img src="<?php echo base_url(); ?>resources/images/comment_icon.png" >
                <a href="#">view 19 more comments</a>
            </div>
        </div>
        <div class="row padding_top_over_row">
            <div class="col-md-1">
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_4.jpg" width="30" height="30">
            </div>
            <div class="col-md-11">
                <div class="row">
                    <div class="col-md-12">
                        <a style="font-weight: bold;" href="#">Maria Islam</a>
                        Really amazing :)
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        January 08, 2015 at 2:15pm. 
                        <a>like</a>
                        <img src="<?php echo base_url(); ?>resources/images/like_icon.png" >
                        . <a>31</a>
                    </div>
                </div>

            </div>
        </div>
        <div class="row padding_top_over_row">
            <div class="col-md-1">
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_2.jpg" width="30" height="30">
            </div>
            <div class="col-md-11">
                <input type ="text" class="form-control" placeholder="Write a comment">
            </div>
        </div>
    </div>
</div>