<div class="row form-group">
    <div class="col-md-4">
        Mobile Phones
    </div>
    <div class="col-md-4">
        <div class="row">
            <div class="col-md-12">
                01912314466 
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                01675393840
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="pull-right">
            <button type="button" class="btn btn_style btn-default dropdown-toggle"  id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true">
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Edit</a></li>
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Delete</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="row form-group">
    <div class="col-md-4">
        Address
    </div>
    <div class="col-md-4">
        <div class="row">
            <div class="col-md-12">
                168, Niketon, Gulshan-1, Dhaka. 
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="pull-right">
            <button type="button" class="btn btn_style btn-default dropdown-toggle"  id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true">
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Edit</a></li>
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Delete</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="row form-group">
    <div class="col-md-4">
        Website
    </div>
    <div class="col-md-4">
        <div class="row">
            <div class="col-md-12">
                http://sampan-it.com/
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="pull-right">
            <button type="button" class="btn btn_style btn-default dropdown-toggle"  id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true">
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Edit</a></li>
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Delete</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="row form-group">
    <div class="col-md-4">
        Email
    </div>
    <div class="col-md-4">
        <div class="row">
            <div class="col-md-12">
               nazmulislamredoy@gmail.com
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="pull-right">
            <button type="button" class="btn btn_style btn-default dropdown-toggle"  id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true">
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Edit</a></li>
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Delete</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="row form-group">
    <div class="col-md-4">
        BirthDay
    </div>
    <div class="col-md-4">
        <div class="row">
            <div class="col-md-12">
              09.03.1988
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="pull-right">
            <button type="button" class="btn btn_style btn-default dropdown-toggle"  id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true">
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Edit</a></li>
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Delete</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="row form-group">
    <div class="col-md-4">
        Gender
    </div>
    <div class="col-md-4">
        <div class="row">
            <div class="col-md-12">
              Male
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="pull-right">
            <button type="button" class="btn btn_style btn-default dropdown-toggle"  id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true">
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Edit</a></li>
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Delete</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="row form-group">
    <div class="col-md-4">
        Languages
    </div>
    <div class="col-md-4">
        <div class="row">
            <div class="col-md-12">
              Bangla, English
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="pull-right">
            <button type="button" class="btn btn_style btn-default dropdown-toggle"  id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true">
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Edit</a></li>
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Delete</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="row form-group">
    <div class="col-md-4">
        Religion
    </div>
    <div class="col-md-4">
        <div class="row">
            <div class="col-md-12">
              Islam
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="pull-right">
            <button type="button" class="btn btn_style btn-default dropdown-toggle"  id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true">
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Edit</a></li>
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Delete</a></li>
            </ul>
        </div>
    </div>
</div>