<div class="pagelet">
    <div class="row">
        <div class="col-md-12">
            <ul style="list-style-type: none; padding: 0;">
                <li>Account Settings</li>
                <li>Privacy Settings</li>
                <li>Log out</li>
            </ul>
        </div>
    </div>
</div>