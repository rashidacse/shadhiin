<div class="row form-group">
    <div class="col-md-12">
        <span style="font-size: 16px; font-weight: bold;">Friend's Documents</span>
    </div>
</div>
<div class="pagelet_divider"></div>
<div class="row padding_top_over_row">
    <div class="col-md-4">
        <div class="img_border">
            <a href="<?php echo base_url() ?>library/library_newsfeed"><img height="150" width="137" src="<?php echo base_url() ?>resources/images/library/08.jpg"></a>
        </div>
        <div class="img_num_border">
            <span>258p</span>
        </div>
        <a href="<?php echo base_url() ?>library/library_newsfeed"><span class="para_title">7 Juboker Golpo</span></a><br>
        <span class="para_author">by <a href="<?php echo base_url() ?>member/profile">Maria Islam</a></span><br>
        <span class="para_default">620 view(s) | 102 like(s)</span>
    </div>
    <div class="col-md-4">
        <div class="img_border">
            <a href="<?php echo base_url() ?>library/library_newsfeed"><img height="150" width="137" src="<?php echo base_url() ?>resources/images/library/09.jpg"></a>
        </div>
        <div class="img_num_border">
            <span>369p</span>
        </div>
        <a href="<?php echo base_url() ?>library/library_newsfeed"><span class="para_title">Sontaner Upor...</span></a><br>
        <span class="para_author">by <a href="<?php echo base_url() ?>member/profile">Fatematul Kobra</a></span><br>
        <span class="para_default">355 view(s) | 52 like(s)</span>
    </div>
    <div class="col-md-4">
        <div class="img_border">
            <a href="<?php echo base_url() ?>library/library_newsfeed"><img height="150" width="137" src="<?php echo base_url() ?>resources/images/library/07.jpg"></a>
        </div>
        <div class="img_num_border">
            <span>582p</span>
        </div>
        <a href="<?php echo base_url() ?>library/library_newsfeed"><span class="para_title">Shirk</span></a><br>
        <span class="para_author">by <a href="<?php echo base_url() ?>member/profile">Mohammad Rafique</a></span><br>
        <span class="para_default">520 view(s) | 39 like(s)</span>
    </div>
</div>
<div class="row padding_top_over_row">
    <div class="col-md-4">
        <div class="img_border">
            <a href="<?php echo base_url() ?>library/library_newsfeed"><img height="150" width="137" src="<?php echo base_url() ?>resources/images/library/01.jpg"></a>
        </div>
        <div class="img_num_border">
            <span>60p</span>
        </div>
        <a href="<?php echo base_url() ?>library/library_newsfeed"><span class="para_title">Hinduism & Islam</span></a><br>
        <span class="para_author">by <a href="<?php echo base_url() ?>member/profile">Mohammad Azhar Uddin</a></span><br>
        <span class="para_default">50 view(s) | 30 like(s)</span>
    </div>
    <div class="col-md-4">
        <div class="img_border">
            <a href="<?php echo base_url() ?>library/library_newsfeed"><img height="150" width="137" src="<?php echo base_url() ?>resources/images/library/03.jpg"></a>
        </div>
        <div class="img_num_border">
            <span>192p</span>
        </div>
        <a href="<?php echo base_url() ?>library/library_newsfeed"><span class="para_title">Hadith : Dawud...</span></a><br>
        <span class="para_author">by <a href="<?php echo base_url() ?>member/profile">Fatematul Kobra</a></span><br>
        <span class="para_default">300 view(s) | 55 like(s)</span>
    </div>
    <div class="col-md-4">
        <div class="img_border">
            <a href="<?php echo base_url() ?>library/library_newsfeed"><img height="150" width="137" src="<?php echo base_url() ?>resources/images/library/02.jpg"></a>
        </div>
        <div class="img_num_border">
            <span>656p</span>
        </div>
        <a href="<?php echo base_url() ?>library/library_newsfeed"><span class="para_title">Understanding...</span></a><br>
        <span class="para_author">by <a href="<?php echo base_url() ?>member/profile">Maria Islam</a></span><br>
        <span class="para_default">20 view(s) | 10 like(s)</span>
    </div>
</div>
<div class="row padding_top_over_row">
    <div class="col-md-4">
        <div class="img_border">
            <a href="<?php echo base_url() ?>library/library_newsfeed"><img height="150" width="137" src="<?php echo base_url() ?>resources/images/library/06.jpg"></a>
        </div>
        <div class="img_num_border">
            <span>66p</span>
        </div>
        <a href="<?php echo base_url() ?>library/library_newsfeed"><span class="para_title">Imaner Dabi</span></a><br>
        <span class="para_author">by <a href="<?php echo base_url() ?>member/profile">Dr. Belal</a></span><br>
        <span class="para_default">200 view(s) | 120 like(s)</span>
    </div>
    <div class="col-md-4">
        <div class="img_border">
            <a href="<?php echo base_url() ?>library/library_newsfeed"><img height="150" width="137" src="<?php echo base_url() ?>resources/images/library/04.jpg"></a>
        </div>
        <div class="img_num_border">
            <span>600p</span>
        </div>
        <a href="<?php echo base_url() ?>library/library_newsfeed"><span class="para_title">Hadith : Bukhari</span></a><br>
        <span class="para_author">by <a href="<?php echo base_url() ?>member/profile">Sharmin Akter</a></span><br>
        <span class="para_default">90 view(s) | 29 like(s)</span>
    </div>
    <div class="col-md-4">
        <div class="img_border">
            <a href="<?php echo base_url() ?>library/library_newsfeed"><img height="150" width="137" src="<?php echo base_url() ?>resources/images/library/05.jpg"></a>
        </div>
        <div class="img_num_border">
            <span>362p</span>
        </div>
        <a href="<?php echo base_url() ?>library/library_newsfeed"><span class="para_title">Hadith : Muslim...</span></a><br>
        <span class="para_author">by <a href="<?php echo base_url() ?>member/profile">Fatematul Kobra</a></span><br>
        <span class="para_default">250 view(s) | 59 like(s)</span>
    </div>
</div>




<div class="row padding_top_over_row">
    <div class="col-md-4">
        <span>1-9 of 555 Results</span>
    </div>
    <div class="col-md-8">
        <nav style="float: right;">
            <ul class="pagination pagination_margin">
                <li>
                    <a href="<?php echo base_url(); ?>videos/videos_iframe" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <li><a href="">1</a></li>
                <li><a href="">2</a></li>
                <li><a href="">3</a></li>
                <li><a href="">4</a></li>
                <li><a href="">5</a></li>
                <li>
                    <a href="" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>
