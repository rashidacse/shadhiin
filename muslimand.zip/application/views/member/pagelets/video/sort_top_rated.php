<div class="row form-group">
    <div class="col-md-12">
        <span style="font-size: 16px; font-weight: bold;">Top Rated</span>
    </div>
</div>
<div class="pagelet_divider"></div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/bLd7Jlgj1E/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Waz</a><br>
        </div>
        <div class="font_10px">
            2,139 views<br>
            by <a href="">Sharmin Akter</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/Ot-0uvKGk5o/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">touchy</a><br>
        </div>
        <div class="font_10px">
            1,132 views<br>
            by <a href="">Fatematul Kobra</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/LQY8naI8g3w/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">family</a><br>
        </div>
        <div class="font_10px">
            932 views<br>
            by <a href="">Maria Islam</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/mMesca14yuQ/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Amazing child</a><br>
        </div>
        <div class="font_10px">
            3,219 views<br>
            by <a href="">Sharmin Akter</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/wqMiI81eF3k/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">cute in Islam</a><br>
        </div>
        <div class="font_10px">
            2,323 views<br>
            by <a href="">Fatematul Kobra</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/AJFKA5bA3zk/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">woman rights in Islam</a><br>
        </div>
        <div class="font_10px">
            4,425 views<br>
            by <a href="">Fatematul Kobra</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/krmJMYNBwHE/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Brain money</a><br>
        </div>
        <div class="font_10px">
            458 views<br>
            by <a href="">Sharmin Akter</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/vD9fqIHUMbU/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">House</a><br>
        </div>
        <div class="font_10px">
            2,102 views<br>
            by <a href="">Barak Obama</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/ORXZOaDgmqM/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">living in Islam</a><br>
        </div>
        <div class="font_10px">
            1,132 views<br>
            by <a href="">Fatematul Kobra</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/jnEumnhHyK8/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">touchy story</a><br>
        </div>
        <div class="font_10px">
            732 views<br>
            by <a href="">Dr. Belal</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/Uj_ztsakS0/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Islam nowadays</a><br>
        </div>
        <div class="font_10px">
            6,685 views<br>
            by <a href="">Maria Islam</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/KLitM-VALV4/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Zakir</a><br>
        </div>
        <div class="font_10px">
            558 views<br>
            by <a href="">Mohammad Rafique</a>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-4">
        <span>1-12 of 2,666 Results</span>
    </div>
    <div class="col-md-8">
        <nav style="float: right;">
            <ul class="pagination pagination_margin">
                <li>
                    <a href="" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <li><a href="">1</a></li>
                <li><a href="">2</a></li>
                <li><a href="">3</a></li>
                <li><a href="">4</a></li>
                <li><a href="">5</a></li>
                <li>
                    <a href="" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>
