<div class="row form-group">
    <div class="col-md-12">
        <span style="font-size: 16px; font-weight: bold;">Friends' Videos</span>
    </div>
</div>
<div class="pagelet_divider"></div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/eps0J53sb_w/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Top 10 Unsportsmanlike Moments in Pro Sports" data-placement="top" data-toggle="tooltip"> Top 10 Unsportsmanlike Moments in Pro Sports</a><br>
        </div>
        <div class="font_10px">
            259 views<br>
            by <a href="">Sharmin Akter</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/QeXXImhgXFo/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="20 Perfectly Timed Sports Photos" data-placement="top" data-toggle="tooltip"> 20 Perfectly Timed Sports Photos</a><br>
        </div>
        <div class="font_10px">
            2,139 views<br>
            by <a href="">Dr. Belal</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/XRtDW4dY814/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="The 25 Best Sports Plays of 2014" data-placement="top" data-toggle="tooltip"> The 25 Best Sports Plays of 2014</a><br>
        </div>
        <div class="font_10px">
            3,901 views<br>
            by <a href="">Sharmin Akter</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/loiHjxnZ-3o/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Should HGH Be LEGAL In Sports?" data-placement="top" data-toggle="tooltip"> Should HGH Be LEGAL In Sports?</a><br>
        </div>
        <div class="font_10px">
            1,259 views<br>
            by <a href="">Sharmin Akter</a>
        </div>
    </div>


    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/he6D_W2MuL0/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="TOP 10 Sports Compact Cars 2016" data-placement="top" data-toggle="tooltip"> TOP 10 Sports Compact Cars 2016</a><br>
        </div>
        <div class="font_10px">
            5,294 views<br>
            by <a href="">Jannatul Ferdaus</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/6JpD_2ZpojM/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Best Football Fights, Fouls, Brawls & Angry Moments | Sports Fights" data-placement="top" data-toggle="tooltip"> Best Football Fights, Fouls, Brawls & Angry Moments | Sports Fights</a><br>
        </div>
        <div class="font_10px">
            5,692 views<br>
            by <a href="">Barak Obama</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row">
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/xyp7br4NOmk/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="We Wear Our Sneakers (Champs Sports Unboxing Skit)" data-placement="top" data-toggle="tooltip"> We Wear Our Sneakers (Champs Sports Unboxing Skit)</a><br>
        </div>
        <div class="font_10px">
            897 views<br>
            by <a href="">Sharmin Akter</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/_lyAEL4Wqao/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="All Sports Golf Battle | Dude Perfect" data-placement="top" data-toggle="tooltip"> All Sports Golf Battle | Dude Perfect</a><br>
        </div>
        <div class="font_10px">
            987 views<br>
            by <a href="">Dr. Belal</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/3jT_q7dt-cM/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Top 10 Crazy Moments in Sports" data-placement="top" data-toggle="tooltip"> Top 10 Crazy Moments in Sports</a><br>
        </div>
        <div class="font_10px">
            2,569 views<br>
            by <a href="">Fatematul Kobra</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row">
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/3UfulU8zxjA/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Greatest Moments In Sports (2004-2014)" data-placement="top" data-toggle="tooltip"> Greatest Moments In Sports (2004-2014)</a><br>
        </div>
        <div class="font_10px">
            2,039 views<br>
            by <a href="">Mohammad Rafique</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/wYQegS-fbwE/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Top 14 Biggest and Longest Sixes in Cricket History updated 2015" data-placement="top" data-toggle="tooltip"> Top 14 Biggest and Longest Sixes in Cricket History updated 2015</a><br>
        </div>
        <div class="font_10px">
            1,262 views<br>
            by <a href="">Maria Islam</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/boHfs7nopHc/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Best Catches in Cricket History! Best Acrobatic Catches! (Please comment the best catch) " data-placement="top" data-toggle="tooltip"> Best Catches in Cricket History! Best Acrobatic Catches! (Please comment the best catch) </a><br>
        </div>
        <div class="font_10px">
            986 views<br>
            by <a href="">Sharmin Akter</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row">
    <div class="col-md-4">
        <span>1-12 of 2,666 Results</span>
    </div>
    <div class="col-md-8">
        <nav style="float: right;">
            <ul class="pagination pagination_margin">
                <li>
                    <a href="" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <li><a href="">1</a></li>
                <li><a href="">2</a></li>
                <li><a href="">3</a></li>
                <li><a href="">4</a></li>
                <li><a href="">5</a></li>
                <li>
                    <a href="" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>
