<div class="row form-group">
    <div class="col-md-12">
        <span style="font-size: 16px; font-weight: bold;">Most Viewed</span>
    </div>
</div>
<div class="pagelet_divider"></div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/RDKbkBa03CE/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Sheikh Motiur Rahman Madani 1</a><br>
        </div>
        <div class="font_10px">
            859 views<br>
            by <a href="">Jannatul Ferdaus</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/OTUoExVeQNI/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Sheikh Motiur Rahman Madani 2</a><br>
        </div>
        <div class="font_10px">
            558 views<br>
            by <a href="">Maria Islam</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/nr_6-_4ryOo/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Sheikh Motiur Rahman Madani 3</a><br>
        </div>
        <div class="font_10px">
            775 views<br>
            by <a href="">Sharmin Akter</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/aw_5sSWV2eE/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Sheikh Motiur Rahman Madani 4</a><br>
        </div>
        <div class="font_10px">
            556 views<br>
            by <a href="">Barak Obama</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/K50ldRZLeNw/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Sheikh Motiur Rahman Madani 5</a><br>
        </div>
        <div class="font_10px">
            859 views<br>
            by <a href="">Jannatul Ferdaus</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/NVOddci6Z8Y/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Sheikh Motiur Rahman Madani 6</a><br>
        </div>
        <div class="font_10px">
            968 views<br>
            by <a href="">Fatematul Kobra</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/95iqXcfnOn8/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Sheikh Motiur Rahman Madani 7</a><br>
        </div>
        <div class="font_10px">
            669 views<br>
            by <a href="">Jannatul Ferdaus</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/7lw2TuXVpBY/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Sheikh Motiur Rahman Madani 8</a><br>
        </div>
        <div class="font_10px">
            979 views<br>
            by <a href="">Dr. Belal</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/XcPtMlg8Hd4/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Sheikh Motiur Rahman Madani 9</a><br>
        </div>
        <div class="font_10px">
            456 views<br>
            by <a href="">Barak Obama</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/xK3HOpsOVVU/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Sheikh Motiur Rahman Madani 10</a><br>
        </div>
        <div class="font_10px">
            672 views<br>
            by <a href="">Mohammad Rafique</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/VVArU1boja4/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Sheikh Motiur Rahman Madani 11</a><br>
        </div>
        <div class="font_10px">
            529 views<br>
            by <a href="">Jannatul Ferdaus</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/nraNki9bLgw/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Sheikh Motiur Rahman Madani 12</a><br>
        </div>
        <div class="font_10px">
            698 views<br>
            by <a href="">Mohammad Rafique</a>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-4">
        <span>1-12 of 2,666 Results</span>
    </div>
    <div class="col-md-8">
        <nav style="float: right;">
            <ul class="pagination pagination_margin">
                <li>
                    <a href="" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <li><a href="">1</a></li>
                <li><a href="">2</a></li>
                <li><a href="">3</a></li>
                <li><a href="">4</a></li>
                <li><a href="">5</a></li>
                <li>
                    <a href="" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>
