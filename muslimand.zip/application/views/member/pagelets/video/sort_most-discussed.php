<div class="row form-group">
    <div class="col-md-12">
        <span style="font-size: 16px; font-weight: bold;">Most Discussed</span>
    </div>
</div>
<div class="pagelet_divider"></div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/Xl1zLHd6gp8/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/NacEIc2oET8/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/uRnWZEUkFRQ/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/gvElrClsCtE/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/Hod05lHgsMg/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/B_kmXOOTwe8/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/Re6T7aLVi1o/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/FgTuWiKSLkI/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/hCe81IJmmDo/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/NIvOrtLto0M/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/qP4d7Mc-uDY/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/gvElrClsCtE/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
    </div>
</div>
<div class="row">
     <div class="col-md-4">
        <span>1-12 of 2,666 Results</span>
    </div>
    <div class="col-md-8">
        <nav style="float: right;">
  <ul class="pagination pagination_margin">
    <li>
      <a href="<?php echo base_url(); ?>videos/videos_iframe" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>
    <li><a href="">1</a></li>
    <li><a href="">2</a></li>
    <li><a href="">3</a></li>
    <li><a href="">4</a></li>
    <li><a href="">5</a></li>
    <li>
      <a href="" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>
    </div>
</div>
