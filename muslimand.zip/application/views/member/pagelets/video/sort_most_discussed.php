<div class="row form-group">
    <div class="col-md-12">
        <span style="font-size: 16px; font-weight: bold;">Most Discussed</span>
    </div>
</div>
<div class="pagelet_divider"></div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/ivO4Mh_VdoU/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Zakir Naik answer</a><br>
        </div>
        <div class="font_10px">
            2,139 views<br>
            by <a href="">Dr. Belal</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/h9uGVSlTMK4/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Critical Ques</a><br>
        </div>
        <div class="font_10px">
            3,901 views<br>
            by <a href="">Sharmin Akter</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/wfeh8oZ3oDg/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Zakir Naik on Colombia</a><br>
        </div>
        <div class="font_10px">
            2,039 views<br>
            by <a href="">Mohammad Rafique</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/EEP0LFo6vqs/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Zakir Naik on Africa</a><br>
        </div>
        <div class="font_10px">
            1,259 views<br>
            by <a href="">Sharmin Akter</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/38MubOtoMXM/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Zakir Naik in public</a><br>
        </div>
        <div class="font_10px">
            5,259 views<br>
            by <a href="">Mohammad Rafique</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/D92WiScx2aY/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Zakir Naik ques & ans</a><br>
        </div>
        <div class="font_10px">
            5,525 views<br>
            by <a href="">Barak Obama</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/AQ7HiY49P3w/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Zakir Naik new</a><br>
        </div>
        <div class="font_10px">
            3,215 views<br>
            by <a href="">Maria Islam</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/xqWxDi3R4Js/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Zakir Naik's Challenge</a><br>
        </div>
        <div class="font_10px">
            5,152 views<br>
            by <a href="">Fatematul Kobra</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/th-rwieyAh0/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Best of Zakir Naik</a><br>
        </div>
        <div class="font_10px">
            3,152 views<br>
            by <a href="">Maria Islam</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/ogfbPh0MkzQ/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Zakir Naik lecture 1</a><br>
        </div>
        <div class="font_10px">
            952 views<br>
            by <a href="">Mohammad Rafique</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/MfzrAMWr1Cc/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Zakir Naik lecture 2</a><br>
        </div>
        <div class="font_10px">
            859 views<br>
            by <a href="">Jannatul Ferdaus</a>
        </div>
    </div>
    <div class="col-md-3">
        <a href="<?php echo base_url(); ?>videos/videos_iframe" >
            <img scrolling="no" src="http://img.youtube.com/vi/kwBDpW7QOmQ/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px">
            <a href="<?php echo base_url(); ?>videos/videos_iframe">Zakir Naik lecture 3</a><br>
        </div>
        <div class="font_10px">
            995 views<br>
            by <a href="">Dr. Belal</a>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-4">
        <span>1-12 of 2,666 Results</span>
    </div>
    <div class="col-md-8">
        <nav style="float: right;">
            <ul class="pagination pagination_margin">
                <li>
                    <a href="" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <li><a href="">1</a></li>
                <li><a href="">2</a></li>
                <li><a href="">3</a></li>
                <li><a href="">4</a></li>
                <li><a href="">5</a></li>
                <li>
                    <a href="" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>
