<div class="row form-group">
    <div class="col-md-12">
        <span style="font-size: 16px; font-weight: bold;">My Videos</span>
    </div>
</div>
<div class="pagelet_divider"></div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/8LVN7WVgx0c/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Top 5 - Technology That Has Changed The World" data-placement="top" data-toggle="tooltip">Top 5 - Technology That Has Changed The World</a><br>
        </div>
        <div class="font_10px">
        5,294 views<br>
        by <a href="">Jannatul Ferdaus</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/lMymFYJWW5M/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="10 Future Technologies That May Change The World" data-placement="top" data-toggle="tooltip">10 Future Technologies That May Change The World</a><br>
        </div>
        <div class="font_10px">
        2,589 views<br>
        by <a href="">Sharmin Akter</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/VxwsBSoenqs/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Awesome Top New Technology Cool Gadgets and Inventions 2015" data-placement="top" data-toggle="tooltip">Awesome Top New Technology Cool Gadgets and Inventions 2015</a><br>
        </div>
        <div class="font_10px">
        1,294 views<br>
        by <a href="">Maria Islam</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/9FxvBFPTtWQ/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="6 Cool New Technologies and Inventions 2015" data-placement="top" data-toggle="tooltip">6 Cool New Technologies and Inventions 2015</a><br>
        </div>
        <div class="font_10px">
        5,294 views<br>
        by <a href="">Jannatul Ferdaus</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/eRCKYLjR7yw/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Top 10 Future Technology That's Here Right Now" data-placement="top" data-toggle="tooltip">Top 10 Future Technology That's Here Right Now</a><br>
        </div>
        <div class="font_10px">
        3,698 views<br>
        by <a href="">Mohammad Rafique</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/oYOmZlTjsQ0/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Future Transportation Technology Will Blow Your Mind" data-placement="top" data-toggle="tooltip">Future Transportation Technology Will Blow Your Mind</a><br>
        </div>
        <div class="font_10px">
        2,687 views<br>
        by <a href="">Fatematul Kobra</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/mePA9VifSPM/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Mysterious technology" data-placement="top" data-toggle="tooltip">Mysterious technology</a><br>
        </div>
        <div class="font_10px">
        2,658 views<br>
        by <a href="">Barak Obama</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/lvtfD_rJ2hE/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Amazing Technology Invented By MIT - Tangible Media" data-placement="top" data-toggle="tooltip">Amazing Technology Invented By MIT - Tangible Media</a><br>
        </div>
        <div class="font_10px">
        1,694 views<br>
        by <a href="">Jannatul Ferdaus</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/tqKpk1wABuI/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Top 10 most Amazing Technologies" data-placement="top" data-toggle="tooltip">Top 10 most Amazing Technologies</a><br>
        </div>
        <div class="font_10px">
        3,987 views<br>
        by <a href="">Maria Islam</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/0aDqZUyJ9Kc/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Awesome Technologies 2016" data-placement="top" data-toggle="tooltip">Awesome Technologies 2016</a><br>
        </div>
        <div class="font_10px">
        5,294 views<br>
        by <a href="">Fatematul Kobra</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/vbNHCn2gHQ4/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Top 5 Future Technology Inventions | 2019 - 2050" data-placement="top" data-toggle="tooltip">Top 5 Future Technology Inventions | 2019 - 2050</a><br>
        </div>
        <div class="font_10px">
        3,294 views<br>
        by <a href="">Dr. Belal</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/M7EvizTkIAE/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Amazing Eco-Friendly Technology That Will Change The World" data-placement="top" data-toggle="tooltip">Amazing Eco-Friendly Technology That Will Change The World</a><br>
        </div>
        <div class="font_10px">
        4,654 views<br>
        by <a href="">Fatematul Kobra</a>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-4">
        <span>1-12 of 2,666 Results</span>
    </div>
    <div class="col-md-8">
        <nav style="float: right;">
            <ul class="pagination pagination_margin">
                <li>
                    <a href="#" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">4</a></li>
                <li><a href="#">5</a></li>
                <li>
                    <a href="#" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>
