<div class="row form-group">
    <div class="col-md-12">
        <span style="font-size: 16px; font-weight: bold;">My Favorites</span>
    </div>
</div>
<div class="pagelet_divider"></div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/HQx5Be9g16U/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="10 Amazing Science Tricks Using Liquid!" data-placement="top" data-toggle="tooltip">10 Amazing Science Tricks Using Liquid! </a><br>
        </div>
        <div class="font_10px">
        2,139 views<br>
        by <a href="">Fatematul Kobra</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/0Ojq-0KKOL0/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="3 Amazing Science Experiments That You Can Do At Home | Dedicated to the Top Fans of This Month" data-placement="top" data-toggle="tooltip">3 Amazing Science Experiments That You Can Do At Home | Dedicated to the Top Fans of This Month</a><br>
        </div>
        <div class="font_10px">
        4,552 views<br>
        by <a href="">Barak Obama</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/NkyEOrQiGMQ/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="10 More Amazing Science Stunts" data-placement="top" data-toggle="tooltip">10 More Amazing Science Stunts</a><br>
        </div>
        <div class="font_10px">
        1,139 views<br>
        by <a href="">Sharmin Akter</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/5NDdp8ucWGg/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="8 Coin Science Experiments Compilation" data-placement="top" data-toggle="tooltip">8 Coin Science Experiments Compilation</a><br>
        </div>
        <div class="font_10px">
        2,556 views<br>
        by <a href="">Jannatul Ferdaus</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/YXfTNcnF9rM/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="10 Science Experiments You Can Do at Home Compilation" data-placement="top" data-toggle="tooltip">10 Science Experiments You Can Do at Home Compilation</a><br>
        </div>
        <div class="font_10px">
        2,569 views<br>
        by <a href="">Mohammad Rafique</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/8XSzJibma1s/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Underwater Candle - Science Experiment" data-placement="top" data-toggle="tooltip">Underwater Candle - Science Experiment </a><br>
        </div>
        <div class="font_10px">
        3,598 views<br>
        by <a href="">Dr. Belal</a>
        </div>
    </div>
</div>
<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/stwJgL2UtZY/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="6 Things Your Body Does That Science Still Can't Explain" data-placement="top" data-toggle="tooltip">6 Things Your Body Does That Science Still Can't Explain</a><br>
        </div>
        <div class="font_10px">
        1,139 views<br>
        by <a href="">Sharmin Akter</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/8xHXx5HARC8/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="5 Crazy Science Stunts, You Won't See At School" data-placement="top" data-toggle="tooltip">5 Crazy Science Stunts, You Won't See At School </a><br>
        </div>
        <div class="font_10px">
        589 views<br>
        by <a href="">Sharmin Akter</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/whkCJCVzUB4/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Edible Science Experiment" data-placement="top" data-toggle="tooltip">Edible Science Experiment</a><br>
        </div>
        <div class="font_10px">
        987 views<br>
        by <a href="">Maria Islam</a>
        </div>
    </div>
</div>

<div class="row form-group"></div>
<div class="row form-group">
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/J1QjgZCcNig/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="10 Science Tricks You Can Try at Home" data-placement="top" data-toggle="tooltip">10 Science Tricks You Can Try at Home</a><br>
        </div>
        <div class="font_10px">
        654 views<br>
        by <a href="">Barak Obama</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/glQ2NrnDHWc/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="3 Simple Science Experiments - Balloons" data-placement="top" data-toggle="tooltip">3 Simple Science Experiments - Balloons</a><br>
        </div>
        <div class="font_10px">
        4,552 views<br>
        by <a href="">Barak Obama</a>
        </div>
    </div>
    <div class="col-md-4">
        <a href="" >
            <img scrolling="no" src="http://img.youtube.com/vi/ia8CKDIur3s/1.jpg" width="120" height="90" frameborder="0" allowfullscreen>
        </a>
        <div class="font_11px url_ellipsis">
            <a href="" title="Super Cool Science Experiments You Can Do At Home" data-placement="top" data-toggle="tooltip">Super Cool Science Experiments You Can Do At Home</a><br>
        </div>
        <div class="font_10px">
        2,365 views<br>
        by <a href="">Sharmin Akter</a>
        </div>
    </div>
</div>
<div class="row">
     <div class="col-md-4">
        <span>1-12 of 2,666 Results</span>
    </div>
    <div class="col-md-8">
        <nav style="float: right;">
  <ul class="pagination pagination_margin">
    <li>
      <a href="" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>
    <li><a href="">1</a></li>
    <li><a href="">2</a></li>
    <li><a href="">3</a></li>
    <li><a href="">4</a></li>
    <li><a href="">5</a></li>
    <li>
      <a href="" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>
    </div>
</div>
