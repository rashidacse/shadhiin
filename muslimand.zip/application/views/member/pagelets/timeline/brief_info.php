<div class="pagelet" style="border: 1px solid lightgray;">
    <div class="row">
        <div class="col-md-2">
            <img src="<?php echo base_url(); ?>resources/images/about_box_1.png" width="20" height="20">
        </div>
        <div class="col-md-10">
            <span>Works at <a style="color: #3B59A9; font-size: 12;" href="#">Sampan-IT</a></span>
        </div>
    </div>
    <div class="row form-group"></div>
    <div class="row">
        <div class="col-md-2">
            <img src="<?php echo base_url(); ?>resources/images/about_box_2.png" width="20" height="20">
        </div>
        <div class="col-md-10">
            <div class="row">
                <div class="col-md-12">
                    <span>Studied at <a style="color: #3B59A9; font-size: 12;" href="#">ABC University</a></span>
                </div>
                <div class="col-md-12">
                    <a style="color: black; font-size: 12; opacity: 0.6;" href="#">Attended from 2010 to 2014</a></span>
                </div>  
            </div>
        </div>
    </div>
    <div class="row form-group"></div>
    <div class="row">
        <div class="col-md-2">
            <img src="<?php echo base_url(); ?>resources/images/about_box_3.png" width="20" height="20">
        </div>
        <div class="col-md-10">
            <span>Lives in <a style="color: #3B59A9; font-size: 12;" href="#">Dhaka, Bangladesh.</a></span>
        </div>
    </div>
    <div class="row form-group"></div>
    <div class="row">
        <div class="col-md-2">
            <img src="<?php echo base_url(); ?>resources/images/about_box_4.png" width="20" height="20">
        </div>
        <div class="col-md-10">
            <div class="row">
                <div class="col-md-12">
                    <span>From <a style="color: #3B59A9; font-size: 12;" href="#">Comilla, Bangladesh</a></span>
                </div>
                <div class="col-md-12">
                    <a style="color: black; font-size: 12; opacity: 0.6;" href="#">Born on 9 March, 1991 (23 years old)</a></span>
                </div>
            </div>
        </div>
    </div>
    <div class="row form-group"></div>
    <div class="row">
        <div class="col-md-2">
            <img src="<?php echo base_url(); ?>resources/images/about_box_1.png"  width="20" height="20">
        </div>
        <div class="col-md-10">
            <span>Followed by <a style="color: #3B59A9; font-size: 12;" href="#">6 people</a></span>
        </div>
    </div>
</div>