


<div class="pagelet" style="border: 1px solid #fff;">
    <div class="row">
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    To see his details with friends, <a href="">send him a friend request. </a>

                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <a href="">8 mutual friends</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <button  class="addFriendRequestId btn btn-default pull-right form-control" style="background-color: #703684; color: white" ng-click="addFriend()" id="friendId" >Add Friend</button>
            <button style="display: none" class=" FriendRequestSentId btn btn-default pull-right form-control" style="background-color: #703684; color: white" ng-click="" id="friendId" >Friend Request Sent</button>
        </div>
    </div>
</div>