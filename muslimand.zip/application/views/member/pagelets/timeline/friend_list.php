<div class="pagelet" style="border: 1px solid #fff;">
    <div class="row">
        <div class="col-md-12">
            <a class="non_friend_pagelet_header_anchor_style" href="">Friends</a> ·  <a class="non_friend_pagelet_header_anchor_style" href="">207</a>  <a class="non_friend_pagelet_header_anchor_style" href="">(1 Mutual)</a>
        </div>
    </div>
</div>
<div class="pagelet" style="border: 1px solid #fff;">
    <div class="row">
        <div class="col-md-4">
            <div class="friend_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_1.jpg"  >
                <span class="img_caption">Dr. Belal</span>
            </a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="friend_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_2.jpg"  >
                <span class="img_caption">Mohammad Azhar Uddin</span>
            </a>
            </div>
        </div>
        <div class="col-md-4">
           <div class="friend_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_3.jpg"  >
                <span class="img_caption">Barak Obama</span>
            </a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="friend_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_4.jpg"  >
                <span class="img_caption">Maria Islam</span>
            </a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="friend_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_5.jpg"  >
                <span class="img_caption">Jannatul Ferdaus</span>
            </a>
            </div>
        </div>
        <div class="col-md-4">
           <div class="friend_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_6.jpg"  >
                <span class="img_caption">Fatematul Kobra</span>
            </a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="friend_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_7.jpg"  >
                <span class="img_caption">Sharmin Akter</span>
            </a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="friend_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_8.jpg"  >
                <span class="img_caption">Mohammad Rafique</span>
            </a>
            </div>
        </div>
        <div class="col-md-4">
           <div class="friend_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_9.jpg"  >
                <span class="img_caption">Nazrul Islam</span>
            </a>
            </div>
        </div>
    </div>
</div>