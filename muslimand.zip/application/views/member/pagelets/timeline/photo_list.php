<div class="pagelet" style="border: 1px solid #fff;">
    <div class="row">
        <div class="col-md-12">
            <a class="non_friend_pagelet_header_anchor_style" href="">Photos</a>
        </div>
    </div>
</div>
<div class="pagelet" style="border: 1px solid #fff;">
    <div class="row">
        <div class="col-md-4">
            <div class="photo_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/photos/view_my_photos/01.jpg"  >
            </a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="photo_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/photos/view_my_photos/02.jpg"  >
             </a>
            </div>
        </div>
        <div class="col-md-4">
           <div class="photo_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/photos/view_my_photos/03.jpg"  >
            </a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="photo_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/photos/view_my_photos/04.jpg"  >
            </a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="photo_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/photos/view_my_photos/05.jpg"  >
            </a>
            </div>
        </div>
        <div class="col-md-4">
           <div class="photo_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/photos/view_my_photos/06.jpg"  >
            </a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="photo_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/photos/view_my_photos/07.jpg"  >
            </a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="photo_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/photos/view_my_photos/08.jpg"  >
             </a>
            </div>
        </div>
        <div class="col-md-4">
           <div class="photo_list_img_style">
            <a href="" >
                <img src="<?php echo base_url(); ?>resources/images/photos/view_my_photos/09.jpg"  >
            </a>
            </div>
        </div>
    </div>
</div>