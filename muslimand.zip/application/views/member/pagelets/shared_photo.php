<div class="pagelet">
    <div class="row form-group">
        <div class="col-md-12">
            <div style="float: left; padding-right: 10px;">
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_7.jpg" width="40" height="40">
            </div>
            <div style="float: left;">
                <div>
                    <a style="font-weight: bold;"href="#">Sharmin Akter</a> shared 
                    <a href="#">Jannatul Ferdaus</a>'s photo.
                    <ul style="list-style-type: none; float: right;">
                        <li class="dropdown">
                            <div>
                                <img src="<?php echo base_url(); ?>resources/images/friends_icon.png" width="15" height="15">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="#">Everyone</a></li>
                                    <li><a href="#">Friends</a></li>
                                    <li><a href="#">Friends of friends</a></li>
                                    <li><a href="#">Only Me</a></li>
                                    <li><a href="#">Custom</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
                <div>
                    January 7, 2015 at 10:45am.
                </div>
            </div>
            <div style="float: right;">
                <ul style="list-style-type: none;">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span class="caret"></span></a>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="#">Report</a></li>
                            <li><a href="#">Delete</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!--    <div class="row form-group">
            <div class="col-md-1">
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_7.jpg" width="40" height="40">
            </div>
            <div class="col-md-10">
                <div class="row">
                    <div class="col-md-12">
                        <a style="font-weight: bold;"href="#">Sharmin Akter</a> shared 
                <a href="#">Jannatul Ferdaus</a>'s photo.
                        <button style="max-width: 35px; max-height: 30px; background-color: white;"type="button" class="btn btn-xs" aria-label="Left Align">
                            <img src="<?php echo base_url(); ?>resources/images/friends_icon.png" width="15" height="15"><span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
                        </button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        January 7, 2015 at 10:45am.
                    </div>
                </div>
            </div>
            <div class="col-md-1">
                <button style="background-color: white;"type="button" class="btn btn-xs" aria-label="Left Align">
                    <span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
                </button>
            </div>
        </div>-->



    <div class="row form-group">
        <div class="col-md-11">
            <img class="img-responsive" src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_5.jpg" width="100%" height="60%">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <a style="color: #3B59A9;" href="#">Like</a> .
            <a style="color: #3B59A9;" href="#"> Comment</a> .
            <a style="color: #3B59A9;" href="#"> Share</a>
        </div>
    </div>
</div>
<div class="pagelet">
    <div class="row form-group">
        <div class="col-md-12">
            <img src="<?php echo base_url(); ?>resources/images/like_icon.png">
            <a href="#">37 people </a> like this.
        </div>
    </div>
    <div class="pagelet_divider"></div>
    <div class="row form-group">
        <div class="col-md-12">
            <img src="<?php echo base_url(); ?>resources/images/share_icon.png">
            <a href="#">3 shares</a>
        </div>
    </div>
    <div class="pagelet_divider"></div>
    <div class="row form-group">
        <div class="col-md-12">
            <img src="<?php echo base_url(); ?>resources/images/comment_icon.png">
            <a href="#">view 19 more comments</a>
        </div>
    </div>
    <div class="row form-group">
        <div class="col-md-1">
            <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_4.jpg" width="30" height="30">
        </div>
        <div class="col-md-11">
            <div class="row">
                <div class="col-md-12">
                    <a style="font-weight: bold;" href="#">Maria Islam</a>
                    Nice pic :)
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    January 08, 2015 at 2:15pm. 
                    <a>like</a>
                    <img src="<?php echo base_url(); ?>resources/images/like_icon.png">
                    . <a>31</a>
                </div>
            </div>

        </div>
    </div>
    <div class="row">
        <div class="col-md-1">
            <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_2.jpg" width="30" height="30">
        </div>
        <div class="col-md-11">
            <input type ="text" class="form-control" placeholder="Write a comment">
        </div>
    </div>
</div>
