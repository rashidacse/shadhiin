<div class="pagelet" style="border: 1px solid #fff;">
    <div class="row">
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    To see his details with friends, <a href="">send him a friend request. </a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <a href="">8 mutual friends</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <?php // if ($relation_ship_status == RELATION_TYPE_NON_FRIEND_ID) { ?>
            <!--<button type="button" class=" btn btn-default" style="position: absolute; bottom: 20px; right:  160px; font-size: 80%" ng-click="addFriend()" >Add Friend</button>-->
            <?php // } elseif ($relation_ship_status == RELATION_TYPE_FRIEND_ID) { ?>
            <!--<button type="button" class=" btn btn-default" style="position: absolute; bottom: 20px; right:  160px; font-size: 80%" ng-click="addFriend()" >Friend</button>-->
            <?php // } elseif ($relation_ship_status == RELATION_TYPE_PENDING_ID) { ?>
            <!--<button type="button" class=" btn btn-default  " style=" position: absolute; bottom: 20px; right:  160px; font-size: 80%" ng-click="" >Friend Request Sent</button>-->    
            <?php // } ?>
            <!--            <button  class="addFriendRequestId btn btn-default pull-right form-control" style="background-color: #703684; color: white" ng-click="addFriend()" id="friendId" >Add Friend</button>
                        <button style="display: none" class=" FriendRequestSentId btn btn-default pull-right form-control" style="background-color: #703684; color: white" ng-click="" id="friendId" >Friend Request Sent</button>-->
        </div>
    </div>
</div>