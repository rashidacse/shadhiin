<div class="row form-group">
    <div class="col-md-12">
        <div style="background-color: whitesmoke; margin-left: -15px;">
            <div aria-label="..." role="group" class="btn-group">
                <a id="timelinePageMenu" href="<?php echo base_url(); ?>pages/timeline/{{PageBasicInfo.pageId}}" style="font-size: 100%" class="btn btn-default">Timeline</a>
                <a id="aboutPageMenu" href="" style="font-size: 100%" class="btn btn-default get_over_view_class">About</a>
                <a href="" style="font-size: 100%" class="btn btn-default">Photos</a>
                <a href="" style="font-size: 100%" class="btn btn-default">Videos</a>
            </div>
        </div>
    </div>
</div>
