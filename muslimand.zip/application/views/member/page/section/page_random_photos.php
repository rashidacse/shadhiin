<div id="page_random_photos"  class="pagelet" style="margin-left: -15px; margin-right: -15px; margin-bottom: -15px; margin-top: -30px;">
    <div class="row form-group">
        <div class="col-md-4">
            <a href="" >
                <img class="img-responsive" style="border: 1px solid #703684; height: 100px; width: 150px;" src="<?php echo base_url(); ?>resources/images/photos/albums/English_Cotton/01.jpg">
            </a>
        </div>
        <div class="col-md-4">
            <a href="" >
                <img class="img-responsive" style="border: 1px solid #703684; height: 100px; width: 150px;" src="<?php echo base_url(); ?>resources/images/photos/albums/English_Cotton/02.jpg">
            </a>
        </div>
        <div class="col-md-4">
            <a href="" >
                <img class="img-responsive" style="border: 1px solid #703684; height: 100px; width: 150px;" src="<?php echo base_url(); ?>resources/images/photos/albums/English_Cotton/03.jpg">
            </a>
        </div>
    </div>
    <div class="row form-group padding_top_10px">
        <div class="col-md-4">
            <a href="" >
                <img class="img-responsive" style="border: 1px solid #703684; height: 100px; width: 150px;" src="<?php echo base_url(); ?>resources/images/photos/albums/English_Cotton/04.jpg">
            </a>
        </div>
        <div class="col-md-4">
            <a href="" >
                <img class="img-responsive" style="border: 1px solid #703684; height: 100px; width: 150px;" src="<?php echo base_url(); ?>resources/images/photos/albums/English_Cotton/05.jpg">
            </a>
        </div>
        <div class="col-md-4">
            <a href="" >
                <img class="img-responsive" style="border: 1px solid #703684; height: 100px; width: 150px;" src="<?php echo base_url(); ?>resources/images/photos/albums/English_Cotton/06.jpg">
            </a>
        </div>
    </div>
    <div class="row form-group padding_top_10px">
        <div class="col-md-4">
            <a href="" >
                <img class="img-responsive" style="border: 1px solid #703684; height: 100px; width: 150px;" src="<?php echo base_url(); ?>resources/images/photos/albums/English_Cotton/07.jpg">
            </a>
        </div>
        <div class="col-md-4">
            <a href="" >
                <img class="img-responsive" style="border: 1px solid #703684; height: 100px; width: 150px;" src="<?php echo base_url(); ?>resources/images/photos/albums/English_Cotton/08.jpg">
            </a>
        </div>
        <div class="col-md-4">
            <a href="" >
                <img class="img-responsive" style="border: 1px solid #703684; height: 100px; width: 150px;" src="<?php echo base_url(); ?>resources/images/photos/albums/English_Cotton/09.jpg">
            </a>
        </div>
    </div>
    <div class="row form-group padding_top_10px">
        <div class="col-md-4">
            <a href="" >
                <img class="img-responsive" style="border: 1px solid #703684; height: 100px; width: 150px;" src="<?php echo base_url(); ?>resources/images/photos/albums/English_Cotton/10.jpg">
            </a>
        </div>
        <div class="col-md-4">
            <a href="" >
                <img class="img-responsive" style="border: 1px solid #703684; height: 100px; width: 150px;" src="<?php echo base_url(); ?>resources/images/photos/albums/English_Cotton/11.jpg">
            </a>
        </div>
        <div class="col-md-4">
            <a href="" >
                <img class="img-responsive" style="border: 1px solid #703684; height: 100px; width: 150px;" src="<?php echo base_url(); ?>resources/images/photos/albums/English_Cotton/12.jpg">
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-5">
            <span>1-12 of 2,666 Results</span>
        </div>
        <div class="col-md-7">
            <nav style="float: right;">
                <ul class="pagination pagination_margin">
                    <li>
                        <a href="<?php echo base_url(); ?>videos/videos_iframe" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                    <li><a href="">1</a></li>
                    <li><a href="">2</a></li>
                    <li><a href="">3</a></li>
                    <li><a href="">...</a></li>
                    <li>
                        <a href="" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>
