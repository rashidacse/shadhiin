<div class="pagelet" style="border: 1px solid #fff;">
    <div class="row">
        <div class="col-md-12">
            <a class="non_friend_pagelet_header_anchor_style font_bold" href="">About</a>
        </div>
    </div>
</div>
<div class="pagelet" style="border: 1px solid #fff;">
    <div class="row">
        <div class="col-md-12">
            <label>{{PageBasicInfo.street}}</label><br>
            <label>{{PageBasicInfo.city}}</label><br>
            <label>{{PageBasicInfo.phone}}</label>
        </div>
    </div>
</div>