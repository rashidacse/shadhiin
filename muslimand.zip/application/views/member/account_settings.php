<div class="row form-group">
    <!--LEFT_COLUMN-->
    <div class="col-md-2">
        <div class="row form-group"></div>
        <div class="row form-group">
            <div class="col-md-12">
                <a style="color: black;" href="#">Account</a>
            </div>
        </div>
        <div class="pagelet_divider"></div>
        <div class="row form-group">
            <div class="col-md-12">
                <a style="color: black;" href="#">Security</a>
            </div>
        </div>
        <div class="pagelet_divider"></div>
        <div class="row form-group">
            <div class="col-md-12">
                <a style="color: black;" href="#">Privacy</a>
            </div>
        </div>
        <div class="pagelet_divider"></div>
        <div class="row form-group">
            <div class="col-md-12">
                <a style="color: black;" href="#">Notifications</a>
            </div>
        </div>
        <div class="pagelet_divider"></div>
        <div class="row form-group">
            <div class="col-md-12">
                <a style="color: black;" href="#">Blocking</a>
            </div>
        </div>
    </div>
    <!--  Middle Column-->
    <div class="col-md-8">
        <div class="pagelet">
            <div class="row form-group">
                <div class="col-md-12">
                    <div class="pagelet_title">Account Settings</div>
                </div>
            </div>
            <div class="pagelet_divider"></div>
            <div class="row form-group">
                <div class="col-md-3">
                    Name
                </div>
                <div class="col-md-8">
                    Mohammad Azhar Uddin
                </div>
                <div class="col-md-1">
                    <a href="#">Edit</a> 
                </div>
            </div>
            <div class="pagelet_divider"></div>
            <div class="row form-group">
                <div class="col-md-3">
                    Username
                </div>
                <div class="col-md-8">
                    https://www.muslimand.com/mohammad.azhar.uddin
                </div>
                <div class="col-md-1">
                    <a href="#">Edit</a> 
                </div>
            </div>
            <div class="pagelet_divider"></div>
            <div class="row form-group">
                <div class="col-md-3">
                    Email
                </div>
                <div class="col-md-8">
                    mohammad.azhar.uddin@muslimand.com
                </div>
                <div class="col-md-1">
                    <a href="#">Edit</a> 
                </div>
            </div>
            <div class="pagelet_divider"></div>
            <div class="row form-group">
                <div class="col-md-3">
                    Password
                </div>
                <div class="col-md-8">
                    Password has changed two months ago
                </div>
                <div class="col-md-1">
                    <a href="#">Edit</a> 
                </div>
            </div>
            <div class="pagelet_divider"></div>
            <div class="row form-group">
                <div class="col-md-3">
                    Networks
                </div>
                <div class="col-md-8">
                    No Networks
                </div>
                <div class="col-md-1">
                    <a href="#">Edit</a> 
                </div>
            </div>
            <div class="pagelet_divider"></div>
            <div class="row form-group">
                <div class="col-md-3">
                    Language
                </div>
                <div class="col-md-8">
                    English(US)
                </div>
                <div class="col-md-1">
                    <a href="#">Edit</a> 
                </div>
            </div>
            <div class="pagelet_divider"></div>
        </div>
    </div>
    <div class="col-md-2"></div>   
</div>
<div style="padding-bottom: 180px;"></div>