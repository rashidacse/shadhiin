<div style="height: 50%; overflow-x:hidden; overflow-y: scroll">
    <div class="ticker_friends message_friends_divider_others">
        <div class="row">
            <div class="col-md-2">
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_8.jpg"  width="30" height="30"> 
            </div>
            <div class="col-md-10">
                <b>Mohammad Rafique</b></a> shared a video.
            </div>
        </div>
    </div>
    <div class="ticker_friends message_friends_divider_others">
        <div class="row">
            <div class="col-md-2">
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_5.jpg"  width="30" height="30"> 
            </div>
            <div class="col-md-10">
                <b>Jannatul Ferdaus</b></a> changed her profile pic.
            </div>
        </div>
    </div>
    <div class="ticker_friends message_friends_divider_others">
        <div class="row">
            <div class="col-md-2">
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_7.jpg"  width="30" height="30"> 
            </div>
            <div class="col-md-10">
                <b>Sharmin Akter</b></a> likes your comment.
            </div>
        </div>
    </div>
    <div class="ticker_friends message_friends_divider_others">
        <div class="row">
            <div class="col-md-2">
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_1.jpg"  width="30" height="30"> 
            </div>
            <div class="col-md-10">
                <b>Dr. Belal</b></a> shared a video.
            </div>
        </div>
    </div>
    <div class="ticker_friends message_friends_divider_others">
        <div class="row">
            <div class="col-md-2">
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_4.jpg"  width="30" height="30"> 
            </div>
            <div class="col-md-10">
                <b>Maria Islam</b></a> likes your photos. 
            </div>
        </div>
    </div>
    <div class="ticker_friends message_friends_divider_others">
        <div class="row">
            <div class="col-md-2">
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_3.jpg"  width="30" height="30"> 
            </div>
            <div class="col-md-10">
                <b>Barak Obama</b></a> likes your photos. 
            </div>
        </div> 
    </div>
    <div class="ticker_friends message_friends_divider_others">
        <div class="row">
            <div class="col-md-2">
                <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_6.jpg"  width="30" height="30"> 
            </div>
            <div class="col-md-10">
                <b>Fatematul Kobra</b></a> likes your comments. 
            </div>
        </div> 
    </div>
</div>
<!--Chat box-->
<div style="border-bottom: 2px solid lightgray"></div>
<div style="height: 50%; overflow-x:hidden; overflow-y: scroll">
    <div class="row">
        <div class="col-md-12">
            <div class="ticker_friends message_friends_divider_others">
                <div class="row">
                    <div class="col-md-3">
                        <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_1.jpg"  width="30" height="30">
                    </div>
                    <div class="col-md-9">
                        <h6><b>Dr. Belal</b></h6>
                    </div>
                </div> 
            </div>
            <div class="ticker_friends message_friends_divider_others">
                <div class="row">
                    <div class="col-md-3">
                        <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_7.jpg"  width="30" height="30">
                    </div>
                    <div class="col-md-9">
                        <h6><b> Sharmin Akter</b></h6>
                    </div>
                </div>
            </div>
            <div class="ticker_friends message_friends_divider_others">
                <div class="row">
                    <div class="col-md-3">
                        <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_8.jpg"  width="30" height="30">
                    </div>
                    <div class="col-md-9">
                        <h6><b>Mohammad Rafique</b></h6>
                    </div>
                </div> 
            </div>
            <div class="ticker_friends message_friends_divider_others">
                <div class="row">
                    <div class="col-md-3">
                        <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_6.jpg"  width="30" height="30">
                    </div>
                    <div class="col-md-9">
                        <h6><b>Fatematul Kobra</b></h6>
                    </div>
                </div>
            </div>
            <div class="ticker_friends message_friends_divider_others">
                <div class="row">
                    <div class="col-md-3">
                        <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_3.jpg"  width="30" height="30">
                    </div>
                    <div class="col-md-9">
                        <h6><b>Barak Obama</b></h6>
                    </div>
                </div>
            </div>
            <div class="ticker_friends message_friends_divider_others">
                <div class="row">
                    <div class="col-md-3">
                        <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_5.jpg"  width="30" height="30">
                    </div>
                    <div class="col-md-9">
                        <h6><b>Jannatul Ferdaus</b></h6>
                    </div>
                </div>
            </div>
            <div class="ticker_friends message_friends_divider_others">
                <div class="row">
                    <div class="col-md-3">
                        <img src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_4.jpg"  width="30" height="30">
                    </div>
                    <div class="col-md-9">
                        <h6><b>Maria Islam</b></h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
