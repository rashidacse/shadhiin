<div class="row form-group"></div>
<div class="row">
    <div class="col-xs-5 col-sm-5 col-md-12">
        <img class="img-circle" src="<?php echo base_url(); ?>resources/images/user_data/profile_pictures/profile_pictures_2.jpg" width="100" height="100">
    </div>
</div>
<div class="row">
    <div class="col-xs-5 col-sm-5 col-md-12">
        <a style="color: black; font-size: 12px; font-weight: bold;" href="#">Mohammad Azhar Uddin</a>
    </div>
</div>
<div class="row">
    <div class="col-xs-2 col-sm-2 col-md-12">
        <a style="color: black; font-size: 12px;" href="#">Edit Profile</a>
    </div>
</div>
<div class="row form-group"></div>