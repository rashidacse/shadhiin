<ul class="video_ul">
    <a href="<?php echo base_url(); ?>member/newsfeed"><li>News Feed</li></a>
    <a href="<?php echo base_url(); ?>member/messages"><li>Messages</li></a>
    <a href="<?php echo base_url(); ?>friend/get_friend_list"><li>Friends</li></a>
    <a href="<?php echo base_url(); ?>photos/"><li>Photos</li></a>
    <a href="<?php echo base_url(); ?>videos/"><li>Videos</li></a>
    <!--<a href="<?php // echo base_url();  ?>blogs/"><li>Blogs</li></a>-->
    <a href="<?php echo base_url(); ?>pages/pages_newsfeed"><li class="cursor_holder_style">Pages
            <ul class="video_ul" style="margin-left: 15px;">
                <a href="<?php echo base_url(); ?>pages/pages_add"><li>Create a Page</li></a>
<!--                <div ng-repeat="">
                <a href=""><li>{{PageBasicInfo.title}}</li></a>
                </div>-->
            </ul>    
        </li></a>
    <!--<a href="<?php // echo base_url();  ?>academy/"><li>Academy</li></a>-->
    <!--<a href="<?php // echo base_url();  ?>library/"><li>Library</li></a>-->
    <!--<a href="<?php // echo base_url();  ?>fund/"><li>Fund Raising</li></a>-->
    <!--<a href="#"><li>Online Payment</li></a>-->
    <!--<a href="<?php // echo base_url();  ?>member/zakat"><li>Zakat</li></a>-->
    <!--<a href="#"><li>Shopping</li></a>-->
</ul>