<label class="label_padding_top" >Select a Category</label><br>
<select class="form-control page_custom_form_control" name="control">
    <option selected="1">Select a Category</option>
    <option value="0">Appliances</option>
    <option value="1">Baby Goods/Kids Goods</option>
    <option value="2">Bags/Luggage</option>
    <option value="3">Building Materials</option>
    <option value="4">Camera/Photo</option>
    <option value="5">Cars</option>
    <option value="6">Health</option>
    <option value="7">Clothing</option>
    <option value="8">Commercial Equipment</option>
    <option value="9">Computers</option>
    <option value="10">Drugs</option>
    <option value="11">Electronics</option>
    <option value="12">Food/Beverages</option>
    <option value="13">Furniture</option>
    <option value="14">Games/Toys</option>
    <option value="15">Beauty</option>
    <option value="16">Home Decor</option>
    <option value="17">Household Supplies</option>
    <option value="18">Jewelry/Watches</option>
    <option value="19">Kitchen/Cooking</option>
    <option value="20">Movies/Music</option>
    <option value="21">Musical Instrument</option>
    <option value="22">Office Supplies</option>
    <option value="23">Outdoor Gear/Sporting Goods</option>
    <option value="24">Patio/Garden</option>
    <option value="25">Pet Supplies</option>
    <option value="26">Product/Service</option>
    <option value="27">Software</option>
    <option value="28">Tools/Equipment</option>
    <option value="29">Vitamins/Supplements</option>
    <option value="30">Website</option>
    
</select>