<label class="label_padding_top" >Select a Category</label><br>
<select class="form-control page_custom_form_control" name="control">
    <option selected="1">Select a Category</option>
    <option value="0">Business</option>
    <option value="1">Common Interest</option>
    <option value="2">Entertainment</option>
    <option value="3">Arts</option>
    <option value="4">Geography</option>
    <option value="5">Internet</option>
    <option value="6">Technology</option>
    <option value="7">Just for Fun</option>
    <option value="8">Music</option>
    <option value="9">Organizations</option>
    <option value="10">Sports</option>
    <option value="11">Recreation</option>
    <option value="12">Student Groups</option>
</select>