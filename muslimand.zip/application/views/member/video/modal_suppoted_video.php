<div class="modal fade" id="modal_suppoted_video" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal_dialog">
        <div class="modal-content modal_background_color">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <div style="text-align: center;"><h4 class="modal-title" id="myModalLabel">Supported Sites</h4></div>
            </div>
            <div class="modal-body" style="padding-left: 50px;">
                YouTube
            </div>
            <div class="modal-footer">
            </div>
        </div>
    </div>
</div>

<script>
    function open_modal_suppoted_video() {
        $('#modal_suppoted_video').modal('show');
    }
</script>