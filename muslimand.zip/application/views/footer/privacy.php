<div class="container-fluid">
    <div class="row">
        <div class="col-md-offset-1 col-md-10">
            <div class="row padding_top_over_row">
                <div class="col-md-12">
                    <span style="font-size: 24px; font-weight: bold;">Privacy Policy</span>
                </div>
            </div>
            <div class="pagelet_divider"></div>
            <div style="font-size: 12px; text-align: justify;">
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">Last revised and is effective as of: 01.01.2015</p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">Information Collected by Muslimand: </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">IP Addresses: </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">Cookies, Web Beacons and Other Technologies:  </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">Use and Disclosure of Information: </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">Social Networking Sites:  </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">Third-Party Advertisers and Links to Other Websites: </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">Circumstances In Which Ummaland May Release Information:  </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">Your Profile Information:  </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">You Control Who Shares Your Information:   </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">Information You Can Access: </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">Cancelling Your Membership:  </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">Children and Age Restrictions:  </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">Changes in Privacy Policy:   </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p style="font-weight: bold;">Your Comments or Concerns:    </p>
                        <p>Proin nec erat elit. In gravida consequat arcu ut cursus. Donec consectetur mollis risus, 
                            sed dignissim augue tempus a. Vivamus cursus mauris non iaculis pharetra. Duis vel orci 
                            tincidunt nisi efficitur ornare. Cras tristique, dolor et rhoncus ullamcorper, libero sem 
                            rutrum erat, at convallis est sapien ut dolor. Vivamus mattis varius feugiat. Aenean 
                            iaculis tempor suscipit. Duis dui ex, dapibus sed sapien eget, iaculis tincidunt libero. 
                            Proin eros enim, consectetur rutrum ipsum at, varius porttitor tellus. Praesent risus arcu,
                            vehicula vitae sollicitudin nec, efficitur ut odio. Morbi eleifend justo ac tortor pretium 
                            gravida in ut sem. Nulla sapien justo, aliquam nec erat vitae, pellentesque ultrices odio. </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>