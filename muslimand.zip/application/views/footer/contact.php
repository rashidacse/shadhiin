<div class="container">
    <div class="row padding_top_over_row">
        <div class="col-md-12">
            <span style="font-size: 24px; font-weight: bold;">Contact Us</span>
        </div>
    </div>
    <div class="pagelet_divider"></div>
    <div class="row padding_top_over_row">
        <div class="col-md-6">
            <div class="row padding_top_over_row">
                <div class="col-md-12">
                    <label>*Name: </label>
                    <input type="text" class="form-control">
                </div>
            </div>  
            <div class="row padding_top_over_row">
                <div class="col-md-12">
                    <label>*Email: </label>
                    <input type="email" class="form-control">
                </div>
            </div>  
            <div class="row padding_top_over_row">
                <div class="col-md-12">
                    <label>Phone : </label>
                    <input type="email" class="form-control">
                </div>
            </div>  
            <div class="row padding_top_over_row">
                <div class="col-md-12">
                    Muslimand <br>
                    Address <br>
                    Dhaka <br>
                    Bangladesh <br><br>

                    Email: muslimand@muslimand.com<br>
                    Telephone: +880 01XXX XXX XXX
                </div>
            </div>  
        </div>
        <div class="col-md-6">
            <div class="row padding_top_over_row">
                <div class="col-md-12">
                    <label>*Subject: </label>
                    <input type="text" class="form-control">
                </div>
            </div>
            <div class="row padding_top_over_row">
                <div class="col-md-12">
                    <label>*Please describe your question, comment or concern: </label>
                    <textarea rows="6" class="form-control"></textarea>
                </div>
            </div>
            <div class="row padding_top_over_row">
                <div class="col-md-offset-10 col-md-2">
                    <input style="color: #703684" class="form-control" type="button" value="Submit">
                </div>
            </div>
        </div>
    </div>
    <div class="row padding_top_over_row">
        <div class="col-md-12">
            <span style="font-size: 12px; font-weight: bold;">* Required Fields </span>
        </div>
    </div>
</div>