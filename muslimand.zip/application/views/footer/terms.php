<div class="container-fluid">
    <div class="row">
        <div class="col-md-offset-1 col-md-10">
            <div class="row padding_top_over_row">
                <div class="col-md-12">
                    <span style="font-size: 24px; font-weight: bold;">Terms & Conditions of Use</span>
                </div>
            </div>
            <div class="pagelet_divider"></div>
            <div style="font-size: 12px; text-align: justify;">
                <div class="row padding_top_over_row">
                    <div class="col-md-12">
                        <p>Effective as of: 01.01.2016</p>
                        <p style="font-weight: bold;">PLEASE READ THESE TERMS AND CONDITIONS OF USE ("TERMS OF USE") CAREFULLY. 
                            BY ACCESSING OR USING THIS WEB SITE, YOU AGREE TO BE BOUND BY THESE TERMS OF USE.</p>
                        <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                            nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                            Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                            Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                            mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                            at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                            scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                            viverra et a libero.</p>
                    </div>
                </div>
                <div style="font-size: 12px; text-align: justify;">
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>1. Shadhiin Account:</h3>
                            <p style="font-weight: bold;">1.1 Eligibility</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p style="font-weight: bold;">1.2 Registration and Account Security</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p style="font-weight: bold;">1.3 Forum Signature</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p style="font-weight: bold;">1.4 Privacy</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p style="font-weight: bold;">1.5 Subscriptions and Payments</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p style="font-weight: bold;">1.6 Notify us of acts contrary to the Agreement</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>2. MEMBER CONDUCT:</h3>
                            <p style="font-weight: bold;">1.1 Eligibility</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>3. PROHIBITED CONTENT AND ACTIVITY:</h3>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>4. MEMBER DISPUTES</h3>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>5. INTELLECTUAL PROPERTY:</h3>
                            <p>5.1 Ownership</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p>5.2 Content</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p>5.3 Your Content</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p>5.4 Objectionable Content</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p>5.5 Enforcement by Us</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>6. THIRD PARTIES AND OTHER USERS:</h3>
                            <p>6.1 Third Party Content</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p>6.2 Responsibility</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p>6.3 Third-Party Websites and Partner Communities</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>7. VIOLATION OF TERMS:</h3>
                            <p>7.1 Breach of Terms</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p>7.2 Termination of Service</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p>7.3 Effects of Termination</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>8. COPYRIGHT POLICY:</h3>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>9. DISCLAIMER OF WARRANTIES, INDEMNITY AND LIMITATION OF LIABILITY:</h3>
                            <p>9.1 Disclaimer</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p>9.2 Indemnification</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <p>9.3 Limitation of Liability</p>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>10. APPLICABLE LAWS AND THIS AGREEMENT:</h3>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>11. LEGAL COMPLIANCE::</h3>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>12. GENERAL:</h3>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>13. REFUND POLICY FOR ADS:</h3>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>14. CHANGES TO TERMS OF USE:</h3>
                            <p>Donec arcu ante, laoreet sit amet eros et, aliquam pellentesque odio. Sed accumsan convallis risus, 
                                nec scelerisque nulla dignissim efficitur. Aenean feugiat maximus placerat. Quisque lobortis malesuada tortor. 
                                Praesent elementum eu mauris fringilla tempus. Mauris et nunc ac est aliquam ornare eu consectetur nulla. 
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed efficitur 
                                mollis nunc nec iaculis. Nunc hendrerit semper eleifend. Duis viverra porttitor dui non posuere. In ornare 
                                at magna vel porta. Integer vestibulum, mauris eget facilisis vulputate, mi dolor volutpat metus, sed 
                                scelerisque ligula mauris id leo. Sed facilisis lacus quis dapibus rhoncus. In ac quam ac lectus hendrerit 
                                viverra et a libero.</p>
                        </div>
                    </div>
                    <div class="row padding_top_over_row">
                        <div class="col-md-12">
                            <h3>I HAVE READ THIS AGREEMENT AND AGREE TO ALL OF THE PROVISIONS CONTAINED ABOVE.</h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-1"></div>
        </div>
    </div>
</div>