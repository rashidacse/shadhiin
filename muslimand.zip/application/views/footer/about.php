<div class="container-fluid">
    <div class="row padding_top_over_row">
        <div class="col-md-offset-1 col-md-10">


            <div class="row padding_top_over_row">
                <div class="col-md-12">
                    <img style="border-radius: 8px;" class="img-responsive" width="100%" src="<?php echo base_url() ?>resources/images/footer/muslimand.jpg">
                </div>
            </div>
            <div class="row padding_top_over_row">
                <div class="col-md-12">
                    <h2>In the name of Allah, most benevolent, ever-merciful. [Quran - 1:1]</h2>
                </div>
            </div>
            <div class="row padding_top_over_row">
                <div class="col-md-12">
                    <p style="text-align: justify;">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tempus enim sapien, non interdum est congue vitae. Nulla
                        consectetur purus in viverra volutpat. Proin in lobortis lectus. Curabitur consequat nulla eu tortor pulvinar, eget ornare sapien
                        condimentum. Suspendisse nec dolor eu odio laoreet blandit. Maecenas luctus sodales augue a tristique. Proin at dictum
                        libero. Pellentesque dignissim non felis eget imperdiet. Suspendisse consequat, enim et feugiat gravida, neque mi facilisis
                        lectus, id porta erat nisi a nunc. Sed posuere euismod tincidunt. Aliquam in semper turpis. Etiam ac risus vel nunc fringilla
                        interdum vel ac lacus. Phasellus nec augue sit amet libero pellentesque tempus at ut nibh. Donec accumsan, risus sed maximus
                        dignissim, diam ante pulvinar nulla, nec pretium mauris enim in mi. Sed bibendum, massa vitae pharetra accumsan, lectus urna
                        luctus purus, sed condimentum nulla velit et ipsum. Morbi in risus id augue dictum lacinia. 
                    </p>
                </div>
            </div>
            <div class="row padding_top_over_row">
                <div class="col-md-12">
                    <div class="about_div">
                        <p class="about_h3_style">Unity</p>
                        Duis sit amet vulputate dui. Nulla luctus sollicitudin neque, et ullamcorper ex rhoncus eu. Aenean nec lacus porta, vestibulum arcu ut, convallis purus.
                        Integer congue ligula sit amet odio interdum posuere. Duis rutrum porta volutpat. Proin semper rutrum placerat. Fusce faucibus quam at eros convallis efficitur. 
                    </div>
                    <br>
                    <div class="about_div">
                        <p class="about_h3_style">Education</p>
                        Duis sit amet vulputate dui. Nulla luctus sollicitudin neque, et ullamcorper ex rhoncus eu. Aenean nec lacus porta, vestibulum arcu ut, convallis purus.
                        Integer congue ligula sit amet odio interdum posuere. Duis rutrum porta volutpat. Proin semper rutrum placerat. <a href="<?php echo base_url() ?>footer/contact">contact us </a>Fusce faucibus quam at eros convallis efficitur. 
                    </div>
                    <br>
                    <div class="about_div">
                        <p class="about_h3_style">Productivity</p>
                        Duis sit amet vulputate dui. Nulla luctus sollicitudin neque, et ullamcorper ex rhoncus eu. Aenean nec lacus porta, vestibulum arcu ut, convallis purus.
                        Integer congue ligula sit amet odio interdum posuere. Duis rutrum porta volutpat. Proin semper rutrum placerat. Fusce faucibus quam at eros convallis efficitur. 
                    </div>
                    <br>
                    <div class="about_div">
                        <p class="about_h3_style">Charity</p>
                        Duis sit amet vulputate dui. Nulla luctus sollicitudin neque, et ullamcorper ex rhoncus eu. Aenean nec lacus porta, vestibulum arcu ut, convallis purus.
                        Integer congue ligula sit amet odio interdum posuere. Duis rutrum porta volutpat. Proin semper rutrum placerat. Fusce faucibus quam at eros convallis efficitur. 
                    </div>
                    <br>
                    <div class="about_div">
                        <p class="about_h3_style">Community</p>
                        Duis sit amet vulputate dui. Nulla luctus sollicitudin neque, et ullamcorper ex rhoncus eu. Aenean nec lacus porta, vestibulum arcu ut, convallis purus.
                        Integer congue ligula sit amet odio interdum posuere. Duis rutrum porta volutpat. Proin semper rutrum placerat. Fusce faucibus quam at eros convallis efficitur. 
                    </div>
                    <br>
                </div>
            </div>
            <div class="row padding_top_over_row">
                <div class="col-md-12">
                    <p>If you are not a member yet, <a>Sign Up</a> here. If you are already a member, please, Invite your friends and family to Muslimand.</p>
                    <p>May Allah accept our efforts and grant us what is best here and hereafter.</p>
                    <p>Jazzak-Allah Khairan</p>
                    <p>- Friends at Muslimand</p>
                </div>
            </div>





        </div>
        <div class="col-md-1"></div>
    </div>
</div>