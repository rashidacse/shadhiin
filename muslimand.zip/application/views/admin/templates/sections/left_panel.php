<div class="row padding_top_over_row">
    <div class="col-md-12">
        <ul class="admin_panel_left_menu_ul">
            <li class="admin_panel_left_menu_li">Media
                <ul>
                    <a href="<?php echo base_url().'admin/media/photo_categories'?>"><li>Photo</li></a>
                    <a href="<?php echo base_url().'admin/media/video_categories'?>"><li>Video</li></a>
                </ul>
            </li>
            <li style="cursor: pointer;">Log Out</li>
        </ul>
    </div>
</div>