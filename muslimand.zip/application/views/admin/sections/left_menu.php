<div class="row padding_top_over_row">
    <div class="col-md-12">
        <ul class="admin_panel_left_menu_ul">
            <a href=<?php echo base_url(); ?>admin/admin_panel><li>Overview</li></a>
            <li class="admin_panel_left_menu_li">Users
                <ul>
                    <a href=""><li>Overview</li></a>
                    <a href=""><li>User Manage</li></a>
                    <a href=""><li>Reports</li></a>
                </ul>
            </li>
            <li class="admin_panel_left_menu_li">Events
                <ul>
                    <li class="admin_panel_left_menu_li">News Feed
                        <ul style="list-style-type: none; cursor: pointer;">
                            <a href=""><li>Post Status</li></a>
                            <a href=""><li>Shared Status</li></a>
                            <a href=""><li>Shared Link</li></a>
                            <a href=""><li>Shared Photo</li>
                                <a href=""><li>Shared Video</li>
                                    <a href=""><li>Updated Profile Pic</li>
                                        <a href=""><li>Updated Status</li>
                                            </ul>
                                            </li>
                                            <a href=""><li>Messages</li></a>
                                            <a href="<?php echo base_url(); ?>admin/photo_config"><li>Photo</li></a>
                                            <a href="<?php echo base_url(); ?>admin/video_config"><li>Video</li></a>
                                            <a href="<?php echo base_url(); ?>admin/blog_config"><li>Blog</li></a>
                                            <a href="<?php echo base_url(); ?>admin/page_config"><li>Page</li></a>
                                            <a href="<?php echo base_url(); ?>admin/academy_config"> <li>Academy</li></a>
                                            <a href="<?php echo base_url(); ?>admin/library_config"><li>Library</li></a>
                                            <a href="<?php echo base_url(); ?>admin/fund_config"><li>Fund Raising</li></a>
                                            <a href=""><li>Online Payment</li></a>
                                            <a href=""><li>Zakat</li></a>
                                            <a href=""><li>Shopping</li></a>
                                            </ul>
                                            </li>
                                            <li class="admin_panel_left_menu_li">Footer
                                                <ul>
                                                    <a href=""><li>About</li></a>
                                                    <a href=""><li>Contact</li></a>
                                                    <a href=""><li>Invite</li></a>
                                                    <a href=""><li>Privacy</li></a>
                                                    <a href=""><li>Terms</li></a>
                                                </ul>
                                            </li>
                                            <li style="cursor: pointer;">Log Out</li>
                                            </ul>
                                            </div>
                                            </div>