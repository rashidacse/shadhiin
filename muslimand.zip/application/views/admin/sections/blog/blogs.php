<div class="row padding_top_over_row">
    <div class="col-md-2">
        <?php $this->load->view("admin/sections/left_menu"); ?>
    </div>
    <div class="col-md-10">
        <?php $this->load->view("admin/sections/blog/blog_category"); ?>
     </div>
</div>


